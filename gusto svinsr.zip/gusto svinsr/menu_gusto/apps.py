from django.apps import AppConfig


class MenuGustoConfig(AppConfig):
    name = 'menu_gusto'
