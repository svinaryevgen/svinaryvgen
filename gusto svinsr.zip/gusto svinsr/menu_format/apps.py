from django.apps import AppConfig


class MenuFormatConfig(AppConfig):
    name = 'menu_format'
