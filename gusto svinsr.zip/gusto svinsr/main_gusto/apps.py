from django.apps import AppConfig


class MainGustoConfig(AppConfig):
    name = 'main_gusto'
