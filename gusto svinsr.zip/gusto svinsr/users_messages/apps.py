from django.apps import AppConfig


class UsersMessagesConfig(AppConfig):
    name = 'users_messages'
